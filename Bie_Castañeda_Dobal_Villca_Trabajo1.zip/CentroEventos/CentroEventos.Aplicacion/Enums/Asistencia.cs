namespace CentroEventos.Aplicacion.Enums;
public enum Asistencia
{
    Pendiente,
    Presente,
    Ausente,
}