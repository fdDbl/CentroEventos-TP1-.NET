namespace CentroEventos.Aplicacion.Enums;
public enum Permiso
{
    EventoAlta,
    EventoModificacion,
    EventoBaja,
    ReservaAlta,
    ReservaModificacion,
    ReservaBaja,
    UsuarioAlta,
    UsuarioModificacion,
    UsuarioBaja
}